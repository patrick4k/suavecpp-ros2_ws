#pragma once

#include "mavlink/v2.0/common/mavlink.h"
